cadena = input('Dime algo con el símbolo *:')
print(cadena.replace('*', ''))