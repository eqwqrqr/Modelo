a= str(input('Escribe una frase'))
print((a).count(' ')+1)