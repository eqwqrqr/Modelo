n=int(input("numero"))
a=1
for numero in range (1, n+1):

 a= a*numero
print('#', i, 'es el factorial de', n)