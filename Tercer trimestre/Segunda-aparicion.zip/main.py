
frase=str(input("dime una frase:"))
palabra=str(input("¿que letra buscas?"))
primera =frase .find(palabra)
segunda =(frase[primera:]) .rfind(palabra)
print(segunda+1)