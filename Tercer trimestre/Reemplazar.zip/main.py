cadena = input('Escribe una frase que contenga al menos una vez 1.')
print(cadena.replace('1', 'uno'))